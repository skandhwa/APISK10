package MyBasics;

class A7
{
	void display()
	{
		System.out.println("Hello");
	}
}

class A8 extends A7
{
	void test()
	{
		System.out.println("Hi");
	}
}

class A9 extends A8
{
	void demo()
	{
		System.out.println("How r u");
	}
}


public class MultilevelInheritanceEx {

	public static void main(String[] args) {
		
		A9 obj=new A9();
		obj.demo();
		obj.display();
		obj.test();
		

	}

}
