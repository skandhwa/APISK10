package MyBasics;

class A2
{
	int id;
	String name;
	boolean isMarried;
	
	A2(int i,String n)
	{
		id=i;
		name=n;
	}
	
	A2(int i,String n,boolean m)
	{
		id=i;
		name=n;
		isMarried=m;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+isMarried);
	}
	
	
	
	
	
}


public class ParameterizedConstructorEx {

	public static void main(String[] args) {
		
		A2 obj=new A2(1234,"Harry");
		obj.display();
		
		A2 obj1=new A2(3456,"Sam",true);
		obj1.display();
	
		
		

	}

}
