package MyBasics;

class A10
{
	void display()
	{
		System.out.println("Hello");
	}
}

class A11 extends A10
{
	void demo()
	{
		System.out.println("Hi");
	}
}

class A12 extends A10
{
	void test()
	{
		System.out.println("How r u");
	}
}



public class HierarchicalInheritanceEx {

	public static void main(String[] args) {
		
		A11 obj=new A11();
		obj.demo();
		obj.display();
		
		A12 obj1=new A12();
		obj1.test();
		obj1.display();
		

	}

}
