package MyBasics;

class A4
{
	double intrest(int x,int y,int z)
	{
		return x+y+z;
	}
	
	int sum(int a,int b)
	{
		return a+b;
	}
	
}



public class MethodsEx2 {

	public static void main(String[] args) {
		
		A4 obj=new A4();
	System.out.println(obj.intrest(12, 4, 8));	
	
	System.out.println	(obj.sum(10, 25));
		

	}

}
