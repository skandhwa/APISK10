package MyBasics;

class A1
{
	A1()
	{
		System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("Hello");
	}
}



public class ClassesAndObjects {

	public static void main(String[] args) {
		
		A1 obj=new A1();
		obj.display();
		
		

	}

}
