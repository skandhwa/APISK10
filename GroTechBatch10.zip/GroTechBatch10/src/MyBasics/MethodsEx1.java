package MyBasics;

class A3
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void sum(int x,int y)
	{
	int z=x+y;
	System.out.println(z);
	}
	
	int diff(int a,int b)
	{
		return a-b;
	}
	
	
}


public class MethodsEx1 {

	public static void main(String[] args) {
		
		A3 obj=new A3();
		obj.display();
	    obj.sum(23, 55);
	 System.out.println(obj.diff(55, 22));   
		
		

	}

}
