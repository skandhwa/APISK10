package MyBasics;

class A5
{
	void display()
	{
		System.out.println("Hello");
	}
}

class A6 extends A5
{
	void test()
	{
		System.out.println("Hi");
	}
}



public class InheritanceEx1 {

	public static void main(String[] args) {
		
		A6 obj=new A6();
		obj.test();
		obj.display();
		
		
		

	}

}
