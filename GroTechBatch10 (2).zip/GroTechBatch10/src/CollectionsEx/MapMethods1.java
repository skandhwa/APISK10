package CollectionsEx;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MapMethods1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(1, "Apple");
		mp.put(2, "Orange");
		mp.put(8, "Banana");
		mp.put(19, "Mango");
		mp.put(23, "papaya");
		
	String val=	mp.get(2);
	System.out.println(val);
		
		
		Map<Integer,String> mp2=new LinkedHashMap<Integer,String>();
		mp2.put(7, "strawberry");
		mp2.put(3, "kiwi");
		mp2.put(4, "lemon");
		mp2.put(19, "Mango");
		mp2.put(23,"Banana");
		
		
		mp.putAll(mp2);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		
		
		
		
		

	}

}
