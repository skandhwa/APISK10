package CollectionsEx;

import java.util.HashSet;
import java.util.Set;

public class SetEx2 {

	public static void main(String[] args) {
		
		
		Set<Integer> s1=new HashSet<Integer>();
		s1.add(45);
		s1.add(90);
		s1.add(107);
		s1.add(75);
		s1.add(45);
		
		for(Integer x:s1)
		{
			System.out.println(x);
		}
		
	boolean flag=	s1.contains(145);
	
	System.out.println(flag);
		
		

	}

}
