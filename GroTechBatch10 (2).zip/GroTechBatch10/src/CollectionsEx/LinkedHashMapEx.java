package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx {

	public static void main(String[] args) {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		
		mp.put("id",1);
		mp.put("name","harry");
		mp.put("isMarried",true);
		mp.put("salary",780000.76);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+" "+x.getValue());
		}
		
		
		

	}

}
