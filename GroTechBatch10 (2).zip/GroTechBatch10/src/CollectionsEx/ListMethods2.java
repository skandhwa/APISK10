package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ListMethods2 {

	public static void main(String[] args) {
		
		

		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(56);
		
	boolean flag=	li.contains(45);
	
	System.out.println(flag);

	}

}
