package CollectionsEx;

import java.util.LinkedList;
import java.util.List;

public class LinkedListEx1 {

	public static void main(String[] args) {
		
		List<Integer> li=new LinkedList<Integer>();
		li.add(45);
		li.add(67);
		li.add(89);
		li.add(103);
		
		for(int x:li)
		{
			System.out.println(x);
		}
		

	}

}
