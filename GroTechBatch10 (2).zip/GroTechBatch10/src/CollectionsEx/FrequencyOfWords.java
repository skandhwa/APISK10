package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfWords {

	public static void main(String[] args) {
		
		String str="tip tap toe tip tip tap";
		
		String []s=str.split(" ");
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
		for(String x:s)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.println(y.getKey()+"  "+y.getValue());
		}

	}

}
