package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfArray {

	public static void main(String[] args) {
		
		
		int []a= {10,20,30,10,10,20};
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));///mp.put(10,2)
			}
			else
			{
				mp.put(x,1);			
				}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.println(y.getKey()+"  "+y.getValue());
		}
		

	}

}
