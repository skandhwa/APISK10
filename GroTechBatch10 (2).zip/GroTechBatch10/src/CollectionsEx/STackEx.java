package CollectionsEx;

import java.util.Stack;

public class STackEx {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(34);
		stk.push(67);
		
		stk.push(17);

		stk.pop();
		
		System.out.println(stk);
	}

}
