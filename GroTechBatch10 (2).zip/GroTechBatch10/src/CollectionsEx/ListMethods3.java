package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ListMethods3 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(56);
		li.add(67);
		li.add(94);
		
		List<Integer> li2=new ArrayList<Integer>();
		li2.add(23);
		li2.add(45);
		li2.add(6);
	
		
		
//	boolean flag=	li.containsAll(li2);
//	
//	System.out.println(flag);
//	
	
//	li.retainAll(li2);
//
//	for(int x:li)
//	{
//		System.out.println(x);
//	}
//	
	
//		li.removeAll(li2);
//		for(int x:li)
//			{
//				System.out.println(x);
//			}
//		
		
		
//		li.clear();
//		System.out.println(li);
		
//		
//		li.remove(2);
//		
//		System.out.println(li);
		
		
		
		

	}

}
