package CollectionsEx;

import java.util.HashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1, "Apple");
		mp.put(2, "Orange");
		mp.put(8, "Banana");
		mp.put(19, "Mango");
		mp.put(65,"Banana");
		
		mp.put(8, "kiwi");
		
		mp.put(null, "Melon");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		

	}

}
