package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapMethods2 {

	public static void main(String[] args) {
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(1, "Apple");
		mp.put(2, "Orange");
		mp.put(8, "Banana");
		mp.put(19, "Mango");
		mp.put(23, "papaya");
		
		
		Map<Integer,String> mp2=new LinkedHashMap<Integer,String>();
		mp2.put(7, "strawberry");
		mp2.put(3, "kiwi");
		mp2.put(4, "lemon");
		mp2.put(19, "Mango");
		mp2.put(23,"Banana");
		
		
//	boolean flag=	mp.containsKey(2);
//	
//	System.out.println(flag);
		
		
	boolean flag2=	mp.containsValue("Orange");
	
	System.out.println(flag2);
	
	mp.remove(2);
	
	mp.replace(null, null);
	
	

	}

}
