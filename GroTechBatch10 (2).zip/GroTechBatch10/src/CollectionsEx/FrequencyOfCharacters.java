package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfCharacters {

	public static void main(String[] args) {
		
		String str="madam";
		
		char []ch=str.toCharArray();
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		for(char x:ch)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));  /// mp.put(m, 1+1)
			}
			
			else
			{
				mp.put(x,1);
			}
		}
		
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.println(y.getKey()+"  "+y.getValue());
		}
		

	}

}
