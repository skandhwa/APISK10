package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class PrintOnlyUniqueElements {

	public static void main(String[] args) {
		
		int []a= {34,67,89,34,67,99,102};
		
		 

	        Set<Integer> s1 = new LinkedHashSet<>();
	        Set<Integer> s2 = new LinkedHashSet<>();

	        for (Integer x : a) {

	            
	            if (!s1.add(x)) {
	                s2.add(x);
	            }
	        }

	        System.out.println(s2);
		
		

	}

}
