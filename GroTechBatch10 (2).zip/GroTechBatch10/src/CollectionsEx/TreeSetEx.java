package CollectionsEx;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetEx {

	public static void main(String[] args) {
		
		Set<String> s1=new TreeSet<String>();
		s1.add("Apple");
		s1.add("Orange");
		s1.add("Mango");
		s1.add("Banana");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		

	}

}
