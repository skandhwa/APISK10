package CollectionsEx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListEx1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		
		li.add(23);
		li.add(45);
		li.add(90);
		li.add(135);
		
		for(int x:li)
		{
			System.out.println(x);
		}
		
		Iterator itr=li.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		
		
		
		

	}

}
