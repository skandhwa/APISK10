package CollectionsEx;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx1 {

	public static void main(String[] args) {
		
		Queue<String> q1=new PriorityQueue<String>();
		
		q1.add("Harry");
		q1.add("John");
		q1.add("Tom");
		
		q1.remove();
		
		System.out.println(q1);
		

	}

}
