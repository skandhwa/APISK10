package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ListObjects {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		
		li.add("samar");
		li.add(34);
		li.add(false);
		li.add(897654.8976);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
