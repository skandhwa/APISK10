package CollectionsEx;

import java.util.HashSet;
import java.util.Set;

public class SetEx3 {

	public static void main(String[] args) {
		Set<Integer> s1=new HashSet<Integer>();
		s1.add(415);
		s1.add(90);
		s1.add(107);
		s1.add(75);
		s1.add(76);
		
		Set<Integer> s2=new HashSet<Integer>();
		s2.add(45);
		s2.add(90);
		s2.add(107);
		s2.add(35);
		s2.add(25);
//		
//		
//		s1.addAll(s2);
//		
//		System.out.println(s1);
		
		
//	boolean flag=	s1.containsAll(s2);
//	
//	System.out.println(flag);
//		System.out.println(s1);
		
		
//		s1.retainAll(s2);
//		
//		System.out.println(s1);
		
		
//		s1.removeAll(s2);
//		System.out.println(s1);
		
	
		
		

	}

}
