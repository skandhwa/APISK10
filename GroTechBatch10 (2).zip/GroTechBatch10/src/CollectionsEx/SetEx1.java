package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetEx1 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		s1.add("Apple");
		s1.add("Orange");
		s1.add("Mango");
		s1.add("Banana");
		
		System.out.println(s1);
		
		

	}

}
