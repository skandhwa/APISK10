package CollectionsEx;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapEx {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp= new TreeMap<Integer,String>();
		
		mp.put(1, "Apple");
		mp.put(8, "Orange");
		mp.put(19, "Banana");
		mp.put(4, "Mango");
		mp.put(23, "papaya");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		
		
		

	}

}
