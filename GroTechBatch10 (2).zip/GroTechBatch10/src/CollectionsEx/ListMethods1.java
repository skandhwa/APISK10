package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ListMethods1 {

	public static void main(String[] args) {
		
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(56);
		
		List<Integer> li2=new ArrayList<Integer>();
		li2.add(123);
		li2.add(415);
		li2.add(156);
		li2.add(23);
		
		li.addAll(li2);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		
		
		

	}

}
