package StringBasics;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str3="Republic";
		
	str3=	str3.substring(2, 7);
	
	System.out.println(str3);
		

	}

}
