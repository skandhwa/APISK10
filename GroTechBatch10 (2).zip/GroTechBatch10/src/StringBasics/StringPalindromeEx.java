package StringBasics;

public class StringPalindromeEx {

	public static void main(String[] args) {
		
		String str1="madam";
		
		String str=str1;
		
		String revstr="";
		
		for(int i=str1.length()-1;i>=0;i--)//i=4,4>0//i=3,3>0//i=2,2>=0//i=1,1>=0
		{
			revstr=revstr+str1.charAt(i);//revstr=""+m=m//revstr=m+a=ma//revstr=ma+d=mad//madam
		}
		
		System.out.println(revstr);
		
		if(str.equalsIgnoreCase(revstr)==true)
		{
			System.out.println("Both Strings are palindrome");
		}
		else
		{
			System.out.println("Both Strings are not palindrome");
		}
		
		

	}

}
