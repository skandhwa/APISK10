package StringBasics;

public class StringMethods9 {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		char []ch=str.toCharArray();
		
		System.out.println(ch[2]);
		

	}

}
