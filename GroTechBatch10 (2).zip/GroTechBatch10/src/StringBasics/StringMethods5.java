package StringBasics;

public class StringMethods5 {

	public static void main(String[] args) {
		
//		String str="Indian Republic";
//		
//	String []a1=	str.split(" ");
//	
//	System.out.println(a1[0]);
//		
//	System.out.println(a1[1]);
		
		String str="Indian@Republic@test 2";
		
	String []a1=	str.split("@");
	
	System.out.println(a1[0]);
		
		
		

	}

}
