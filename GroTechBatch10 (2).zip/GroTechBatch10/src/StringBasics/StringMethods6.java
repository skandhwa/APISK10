package StringBasics;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="   fac   ebook    ";
		
		str=str.trim();
		
		System.out.println(str);
		

	}

}
