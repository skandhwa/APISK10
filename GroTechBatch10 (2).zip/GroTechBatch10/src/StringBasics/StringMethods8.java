package StringBasics;

public class StringMethods8 {

	public static void main(String[] args) {
		
		String str="apple labs";
		str=str.replace('a','b');
		System.out.println(str);
		
		
		
		

	}

}
