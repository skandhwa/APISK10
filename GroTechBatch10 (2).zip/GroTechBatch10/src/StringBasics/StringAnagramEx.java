package StringBasics;

import java.util.Arrays;

public class StringAnagramEx {

	public static void main(String[] args) {
	
		String str1="brmge";
		String str2="grab";
		
	   if(str1.length()!=str2.length())
	   {
		   System.out.println("Two Strings are not anagram");
	   }
	   
	   else
	   {
		   char []ch1=str1.toCharArray();
		   char []ch2=str2.toCharArray();
		   Arrays.sort(ch1);
		   Arrays.sort(ch2);
		   
		   if(Arrays.equals(ch1,ch2)==true)
		   {
			   System.out.println("Both Strings are anagram");
		   }
		   
		   else
		   {
			   System.out.println("Both Strings are not anagram");
		   }
		   
		   
		   
		   
	   }
		

	}

}
