package StringBasics;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="India";
		int x=str.indexOf('a');
		
		System.out.println("Index of a is  "+x);
		

	}

}
