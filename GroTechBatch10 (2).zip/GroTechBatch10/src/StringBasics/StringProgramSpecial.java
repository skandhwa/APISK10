package StringBasics;

public class StringProgramSpecial {

	public static void main(String[] args) {
		
		String str="abcd&^%$1234ABCD";
		
		str=str.replaceAll("[^0-9]","");
		
		System.out.println(str);
		

	}

}
