package StringBasics;

public class StringDec1 {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		System.out.println(str);
		
		String str1=new String("Harry");
		
		System.out.println(str1);
		

	}

}
