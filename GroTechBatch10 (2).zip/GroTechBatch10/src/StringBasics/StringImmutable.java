package StringBasics;

public class StringImmutable {

	public static void main(String[] args) {
		
		
		String str="Saurabh";
	str=	str.concat("trainer");
		
		System.out.println(str);

	}

}
