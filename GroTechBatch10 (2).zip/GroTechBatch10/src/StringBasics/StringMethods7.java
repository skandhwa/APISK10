package StringBasics;

public class StringMethods7 {

	public static void main(String[] args) {
		
		String str="walmart labs";
		
		str=str.replaceAll(" ","");
		
		System.out.println(str);
		
		
		

	}

}
