package StringBasics;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		str=str.substring(-4);
		
		System.out.println(str);
		

	}

}
