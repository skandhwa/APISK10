package StringBasics;

public class StringMethods1 {

	public static void main(String[] args) {
	
		String str="India";
		
		int x=str.length();
		
		System.out.println("Length of String is  "+x);
		
		String str1="Java";
		String str2=new String("Java").intern();
		
		
		if(str1==str2)
		{
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
		

	}

}
