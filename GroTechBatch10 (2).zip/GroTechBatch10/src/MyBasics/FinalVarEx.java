package MyBasics;

class C4
{
	 final int x=20;
	
	void display()
	{
		x=30;
		System.out.println(x);
		
	}
}


public class FinalVarEx {

	public static void main(String[] args) {
		
		C4 obj=new C4();
		obj.display();
		

	}

}
