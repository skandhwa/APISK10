package MyBasics;

class Bank
{
	  int getROI(int x,int y,int z)
	{
		return x+y+z;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y,int z)
	{
		return x+y+z;
	}
}

class Axis extends Bank
{
	int getROI(int x,int y,int z)
	{
		return x+y+z;
	}
}



public class MethodOverridingEx {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
	System.out.println(obj.getROI(12, 15, 17));	
		

	}

}
