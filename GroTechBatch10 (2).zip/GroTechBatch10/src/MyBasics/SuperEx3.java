package MyBasics;

class C2
{
	void display()
	{
		System.out.println("Python");
	}
}

class C3 extends C2
{
	void run()
	{
		System.out.println("Hello");
	}
	
	void message()
	{
		System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("Java");
	}
	
	void demo()
	{
		run();
		message();
		display();
		super.display();
	}
}



public class SuperEx3 {

	public static void main(String[] args) {
		
		C3 obj=new C3();
		obj.demo();
		

	}

}
