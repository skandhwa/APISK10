package MyBasics;

public class OverloadMainMethods {
	
	
	public static void main(String str)
	{
		System.out.println("Hello");
	}

	public static void main(String[] args) 
	{
		System.out.println("Hi");

	}

}
