package MyBasics;

class C1
{
	void run()
	{
		System.out.println("hello");
	}
	
	void display()
	{
		System.out.println("hi");
	}
	
	void msg()
	{
		System.out.println("Hey");
	}
	
	void demo()
	{
		run();
		display();
		msg();
	}
	
}


public class SuperEx2 {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.demo();
		

	}

}
