package MyBasics;

class B1
{
	static int sum(int a,int b)
	{
		return a+b;
	}
	
	static float sum(float a,int b)
	{
		return a+b;
	}
	
	static int sum(int a,int b,int c)
	{
		return a+b+c;
	}
}


public class MethodOverloading {

	public static void main(String[] args) {
		
	System.out.println(B1.sum(23, 90));	
	
	System.out.println (B1.sum(40.56f, 99));
		

	}

}
