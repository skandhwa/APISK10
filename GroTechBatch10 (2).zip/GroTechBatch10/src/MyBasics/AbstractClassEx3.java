package MyBasics;

abstract class D3
{
	abstract void test();
	
	void display()
	{
		System.out.println("Hello");
	}
	
	int sum(int x,int y)
	{
		return x+y;
	}
	
}

class D4 extends D3
{
	 void test()
	{
		System.out.println("Hi");
	}
}




public class AbstractClassEx3 {

	public static void main(String[] args) {
		
		D4 obj=new D4();
		obj.test();
	System.out.println(obj.sum(12, 15));	
		obj.display();
		

	}

}
