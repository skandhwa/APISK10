package MyBasics;

class B10
{
	String colour="red";
}

class B11 extends B10
{
	String colour="green";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
}



public class SuperEx1 {

	public static void main(String[] args) {
		
		B11 obj=new B11();
		obj.display();
		

	}

}
