package MyBasics;

abstract class AbstractClassEx2 {
	
	void display()
	{
		System.out.println("Hello");
	}
	
	
	abstract void msg();
	
	
	

	public static void main(String[] args) {
		
		
		
		

	}

}
