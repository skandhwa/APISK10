package MyBasics;

interface I10
{
	int id=10;
	void display();
}

class C10 implements I10
{
	public void display()
	{
		System.out.println("Hi");
	}
}


public class InterfaceEx1 {

	public static void main(String[] args) {
		
		I10 ref=new C10();
		ref.display();
		
		C10 obj=new C10();
		obj.display();
		
	System.out.println(I10.id);	
		

	}

}
