package MyBasics;

class C32
{
	int id;
	String name;
	double salary;
	boolean isMarried;
	
	C32(int id,String name,double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
		
	}
	
	C32(int id,String name,double salary,boolean isMarried)
	{
		this(id,name,salary);
		this.isMarried=isMarried;
		
	}
	
	void display()
	{
		System.out.println(name+"  "+id+" "+salary+"  "+isMarried);
	}
	
}


public class ThisKeywordEx2 {

	public static void main(String[] args) {
		
		C32 obj=new C32(1234,"Harry",789999);
		obj.display();
		
		
		

	}

}
