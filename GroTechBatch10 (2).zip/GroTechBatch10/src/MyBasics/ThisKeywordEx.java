package MyBasics;

class C30
{
	int id;
	String name;
	double salary;
	
	C30(int id,String name,double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+" "+salary);
	}
	
	
}

public class ThisKeywordEx {

	public static void main(String[] args) {
		
		C30 obj=new C30(1234,"Harry",9000.67);
		obj.display();
		
		
		
		

	}

}
