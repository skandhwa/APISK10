package MyBasics;

abstract class D1
{
	void display()
	{
		System.out.println("Hello");
	}
	
	abstract void msg();
	
}

class D2 extends D1
{
	void msg()
	{
		System.out.println("Hi");
	}
}



public class AbstractClassEx1 {

	public static void main(String[] args) {
		
		D2 obj=new D2();
		obj.msg();
		obj.display();
		
		D1 ref=new D2();
		ref.msg();
		ref.display();
		

	}

}
