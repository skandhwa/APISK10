package MyBasics;

public class SwitchEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
