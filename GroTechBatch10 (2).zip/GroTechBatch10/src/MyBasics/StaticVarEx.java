package MyBasics;

class C40
{
	int id;
	String name;
	static String comName="TCS";
	
	C40(int id,String name)
	{
		this.id=id;
		this.name=name;
		
	}
	
	void change()
	{
		comName="CTS";
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+comName);
	}
	
	
	
}



public class StaticVarEx {

	public static void main(String[] args) {
		
		
		C40 obj=new C40(1234,"Harry");
		obj.change();
		obj.display();
		C40 obj1=new C40(6789,"Tom");
		obj1.display();
		C40 obj2=new C40(7654,"Dan");
		obj2.display();
		
		

	}

}
