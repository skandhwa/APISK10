package MyBasics;

final class C6
{
	void test()
	{
		System.out.println("Hello");
	}
}

class C7 extends C6
{
	void display()
	{
		System.out.println("Hi");
	}
}

class C8 extends C7
{
	void msg()
	{
		System.out.println("Java");
	}
}


public class FinalForClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
