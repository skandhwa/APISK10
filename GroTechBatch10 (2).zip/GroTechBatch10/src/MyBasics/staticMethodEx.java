package MyBasics;

class C35
{
	static void display()
	{
		System.out.println("Hello");
	}
}





public class staticMethodEx {

	public static void main(String[] args) {
		
		C35.display();
		

	}

}
