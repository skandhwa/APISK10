package MyBasics;

class Shape
{
	final int area(int x,int y)
	{
		return x*y;
	}
}

class Rectangle extends Shape
{
	int area(int x,int y)
	{
		return x+y;
	}
}

class Square  extends Shape
{
	int area(int x,int y)
	{
		return x+y;
	}
}

public class FinalForMethod {

	public static void main(String[] args) {
		

	}

}
