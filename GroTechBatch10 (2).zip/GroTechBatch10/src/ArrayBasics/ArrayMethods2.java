package ArrayBasics;

public class ArrayMethods2 {

	public static void main(String[] args) {
		
		int []a= {12,45,2,67};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)///i=0,0<4//1<4
		{
			sum=sum+a[i];//sum=0+12=12,//sum=12+45=16//
		}
		
		System.out.println(sum);
		

	}

}
