package ArrayBasics;

public class ArrayDeclaration {

	public static void main(String[] args) {
		
		int []a= {12,45,67,3,19};
		
		for(int i=0;i<a.length;i++)//i=0,0<5
		{
			System.out.println(a[i]);//a[0]
		}
		
		System.out.println("##########################################################");
		
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		
		
		
		

	}

}
