package ArrayBasics;

public class StringArray {

	public static void main(String[] args) {
		
		String []a= {"hi","hello","I am"};
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		for(String y:a)
		{
			System.out.println(y);
		}
		
		
		

	}

}
