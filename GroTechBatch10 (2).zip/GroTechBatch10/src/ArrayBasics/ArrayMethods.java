package ArrayBasics;

import java.util.Arrays;

public class ArrayMethods {

	public static void main(String[] args) {
		
		int []a= {45,23,999,1099};
		
		int []b= {45,67,88,99};
		
//		boolean flag=Arrays.equals(a,b);
//		
//		System.out.println(flag);
//		
//		Arrays.sort(a);
//		
//		for(int y:a)
//		{
//			System.out.println(y);
//		}
		
		
		int x=Arrays.compare(a,b);
		
		System.out.println(x);
		

	}

}
