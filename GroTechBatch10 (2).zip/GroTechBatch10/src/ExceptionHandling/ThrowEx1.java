package ExceptionHandling;

class X
{
	public void display(int a)
	{
		if(a<18)
		{
			throw new ArithmeticException("Age is invalid");
		}
		
		else
		{
			System.out.println("Age is valid");
		}
	}
}


public class ThrowEx1 {

	public static void main(String[] args) {
		
		X obj=new X();
		obj.display(13);
		
		
		
		

	}

}
