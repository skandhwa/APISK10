package ExceptionHandling;

public class NullPointerException {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		
		int x=str.length();
		
		System.out.println("Size of string is  "+x);
		}
		
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		

	}

}
