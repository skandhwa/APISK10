package ExceptionHandling;

public class ArrayIndexOutofBoundsEx {

	public static void main(String[] args) {
		
		try
		{
		int []arr= {1,3,4,5};
		
		System.out.println(arr[5]);
		
		}
		
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		
		
		
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		
		

	}

}
