package ExceptionHandling;

public class FinallyBlock {

	public static void main(String[] args) {
		
		try
		{
		
		int a=20;
		int x=a/2;
		System.out.println(x);
		
		}
		
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//		}
		
		finally
		{
		int p=30,q=20;
		int r=p+q;
		System.out.println(r);
		}
		
		

	}

}
