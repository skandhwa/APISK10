package ExceptionHandling;

public class ArithmeticExceptionEx {

	public static void main(String[] args) {
		
		try
		{
		int x=9/0;
		
		System.out.println(x);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with  "+e);
		}
		
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		

	}

}
