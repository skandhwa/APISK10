package ExceptionHandling;

import java.io.File;

public class FileNotFound {

	public static void main(String[] args) {
		
		File f=new File("D:\\Role of AI in Infrastructures and Data Centers_TOC.xlsx");
		
		
		Fi
		
		

	}

}
