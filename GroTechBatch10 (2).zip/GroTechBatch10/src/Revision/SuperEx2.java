package Revision;

class P8
{
	void display()
	{
		System.out.println("hello");
	}
}

class P9 extends P8
{
	void display()
	{
		System.out.println("hi");
	}
	void msg()
	{
		System.out.println("hi");
	}
	void test()
	{
		System.out.println("java");
	}
	
	void run()
	{
		display();
		msg();
		test();
		super.display();
		
	}
	
	
}


public class SuperEx2 {

	public static void main(String[] args) {
		
		P9 obj=new P9();
		obj.run();
		

	}

}
