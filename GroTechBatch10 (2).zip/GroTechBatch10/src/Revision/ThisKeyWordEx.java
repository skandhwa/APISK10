package Revision;

class P11
{
	int id;
	String name;
	double salary;
	
	P11(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	P11(int id,String name,double salary)
	{
		this(id,name);
		this.salary=salary;
	}
	
	
	void display()
	{
		System.out.println(id+" "+name+" "+salary);
	}
	
}


public class ThisKeyWordEx {

	public static void main(String[] args) {
		
		P11 obj=new P11(1234,"Harry");
		obj.display();
		

	}

}
