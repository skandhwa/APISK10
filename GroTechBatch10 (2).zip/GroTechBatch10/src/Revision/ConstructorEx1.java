package Revision;

class P1
{
	P1()
	{
		System.out.println("Hello");
	}
	
	P1(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
	}
	
	void display()
	{
		System.out.println("Hi");
	}
}


public class ConstructorEx1 {

	public static void main(String[] args) {
		
		P1 obj=new P1();
		obj.display();
		
		P1 obj1=new P1(10,20);
		
		
		
		

	}

}
