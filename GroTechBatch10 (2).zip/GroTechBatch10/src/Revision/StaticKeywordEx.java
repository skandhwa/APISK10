package Revision;

class P13
{
	int id;
	String name;
	String 
}

public class StaticKeywordEx {

	public static void main(String[] args) {
		

	}

}
