package Revision;

class P2
{
	int sum(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
		return z;
	}
	
	void diff(int a,int b)
	{
		int p=a-b;
		System.out.println(p);
	}
	
	
	
	
}


public class MethodBasics {

	public static void main(String[] args) {
		
		P2 obj=new P2();
	obj.sum(23, 56);	
	
	obj.diff(78, 45);
		
		

	}

}
