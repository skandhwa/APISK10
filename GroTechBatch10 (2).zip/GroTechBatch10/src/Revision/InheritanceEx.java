package Revision;

class P4
{
	String colour="red";
	void display()
	{
		System.out.println("Hello");
	}
}


class P5 extends P4
{
	String colour="black";
	void test()
	{
		System.out.println("Hi");
	}
	
	void test1()
	{
		System.out.println(super.colour);
		System.out.println(colour);
		
	}
}

class P6 extends P5
{
	void msg()
	{
		System.out.println("Hi everyone");
	}
}





public class InheritanceEx {

	public static void main(String[] args) {
		
		P6 obj=new P6();
		obj.display();
		obj.test();
		obj.msg();
		

	}

}
