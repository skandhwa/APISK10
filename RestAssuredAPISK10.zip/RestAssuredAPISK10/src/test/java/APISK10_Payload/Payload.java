package APISK10_Payload;

public class Payload {
	
	public static String payloadData(String empName,String jobRole)
	{
		String empData="{\r\n"
				+ "    \"name\": \" "+empName+"   \",\r\n"
				+ "    \"job\": \"  "+jobRole+"      \"\r\n"
				+ "}";
		
		return empData;
	}

}
