package APISK10;

public class MyTest1 {

	public static void main(String[] args) {
		
		
		
	}

}
