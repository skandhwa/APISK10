package APISK10;

import org.testng.Assert;

import ResponsePayload.MockJson;
import io.restassured.path.json.JsonPath;

public class MockTestCases {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(MockJson.getResponse());
		
		//// Print No of courses returned by API
		
	int totalCourses=	js.getInt("courses.size()");
	System.out.println("The total size of course is  "+totalCourses);	
	
	//Print Purchase Amount

	int amount=js.getInt("dashboard.purchaseAmount");
	
	System.out.println("Amount is  "+amount);
	
	//Print Title of the first course
    
	String titleFirstCourse=js.getString("courses[0].title");
	System.out.println(titleFirstCourse);
	
	///Print All course titles and their respective Prices
	
	System.out.println("Course title and their respective price is \n");
	for(int i=0;i<totalCourses;i++)
	{
		String title= js.getString("courses["+i+"].title");
		int price=js.getInt("courses["+i+"].price");
		System.out.println(title+"  "+price);
		
	}
	
	///Print no of copies sold by RPA Course

int copies=	js.getInt("courses[2].copies");
System.out.println("total number of copies sold is  "+copies);


///Verify if Sum of all Course prices matches with Purchase Amount


int sum=0;

for(int i=0;i<totalCourses;i++)
{
	int copies1= js.getInt("courses["+i+"].copies");
	int price1=js.getInt("courses["+i+"].price");
	System.out.println(copies1+"  "+price1);
	
	int amount1=copies1*price1;
	
	sum=sum+amount1;
	
	
	
}

Assert.assertEquals(amount, sum);
System.out.println("Test case passed");




	
	
	

	
	

	}

}
