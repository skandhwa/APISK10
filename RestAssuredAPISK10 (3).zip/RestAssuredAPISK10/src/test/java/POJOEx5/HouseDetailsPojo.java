package POJOEx5;

import java.util.List;

public class HouseDetailsPojo {
	
	
	private FlatDetailsPOJO flatobj;
	private String street;
	private List<String> landmark;
	public FlatDetailsPOJO getFlatobj() {
		return flatobj;
	}
	public void setFlatobj(FlatDetailsPOJO flatobj) {
		this.flatobj = flatobj;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public List<String> getLandmark() {
		return landmark;
	}
	public void setLandmark(List<String> landmark) {
		this.landmark = landmark;
	}
	
	
	
	
	
	
	

}
