package POJOEx5;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		FlatDetailsPOJO flobj=new FlatDetailsPOJO();
		flobj.setFlatName("Prem Villa");
		flobj.setFlatNo(23);
		flobj.setFloorNo(1);
		
		
		List<String> li=new ArrayList<String>();
		li.add("ABC sweets");
		li.add("JK hotel");
		li.add("BMC mall");
		
		HouseDetailsPojo hdobj=new HouseDetailsPojo();
		hdobj.setFlatobj(flobj);
		hdobj.setStreet("MG street");
		hdobj.setLandmark(li);
		
	EmployeeAddress4Pojo empAddress=new EmployeeAddress4Pojo();
	
	empAddress.setHdobj(hdobj);
	empAddress.setCity("pune");
	empAddress.setState("Maharastra");
	empAddress.setZip(800032);
	
	CreateEmployee5Pojo emp=new CreateEmployee5Pojo();
	List<String> bank=new ArrayList<String>();
	bank.add("SBI");
	bank.add("HDFC");
	bank.add("ICICI");
	
	emp.setName("Harry");
	emp.setSalary(80000);
	emp.setAge(37);
	emp.setBanks(bank);
	emp.setEmpAddress(empAddress);
	
	ObjectMapper obj=new ObjectMapper();
	
	String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
	
	RestAssured.baseURI="https://reqres.in";
	
	 String res=		given().log().all().
			headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
			headers("content-type","application/json").
			body(empJSON).when().post("api/users").
		    then().log().all().assertThat().statusCode(201)
		    .extract().response().asString();
	 
	 System.out.println(res);
	
	
	
	
	
	
	
		
		
		
		
		

	}

}
