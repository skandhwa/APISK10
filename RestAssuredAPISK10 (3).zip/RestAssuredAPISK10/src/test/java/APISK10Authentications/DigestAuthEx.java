package APISK10Authentications;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;

public class DigestAuthEx {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://postman-echo.com";
		
		String Response=	given().log().all().auth()
				.digest("postman","password")
			.headers("content-type","application/json")
			
			.when().get("digest-auth")
			.then().log().all().extract().response().asString();
		
		System.out.println(Response);
		

	}

}
