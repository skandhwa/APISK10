package GraphQLEx;

import org.json.JSONObject;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;

public class MyRequest1 {

	public static void main(String[] args) {
		
		String query ="{\r\n"
				+ "  country(code: \"FR\") {\r\n"
				+ "    name\r\n"
				+ "    native\r\n"
				+ "    \r\n"
				+ "    currency\r\n"
				+ "  }\r\n"
				+ "}";
		
		
		JSONObject payload=new JSONObject();
		payload.put("query", query);
		
	String reqbody=	payload.toString();
	
String Response=	RestAssured.given().log().all().
baseUri("https://countries.trevorblades.com/")
	.header("content-type","application/json")
	.body(reqbody)
	.when().post().then().log().all().
	assertThat().statusCode(200).extract().response().asString();
		
	System.out.println(Response);	

	}

}
