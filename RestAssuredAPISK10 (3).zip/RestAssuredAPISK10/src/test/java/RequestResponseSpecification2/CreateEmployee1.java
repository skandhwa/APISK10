package RequestResponseSpecification2;

public class CreateEmployee1 {

	public static void main(String[] args) {
		
	String Response=	ReUse.postReq().when().post("api/users")
		.then().spec(ReUse.getRes(201))
		.extract().response().asString();
	
	
	System.out.println(Response);
		
		

	}

}
