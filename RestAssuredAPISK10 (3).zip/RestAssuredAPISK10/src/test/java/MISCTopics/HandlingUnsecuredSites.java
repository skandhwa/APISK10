package MISCTopics;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;

public class HandlingUnsecuredSites {

	public static void main(String[] args) {
		
		

	String Response=	given().log().all().relaxedHTTPSValidation().
			when().get("https://self-signed.badssl.com/")
		.then().extract().response().asString();
	
	System.out.println(Response);
		
		
	}

}
