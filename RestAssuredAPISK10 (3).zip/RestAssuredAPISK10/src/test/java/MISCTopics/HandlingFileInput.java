package MISCTopics;

import static io.restassured.RestAssured.given;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class HandlingFileInput {

	public static void main(String[] args) {
		
		
		File f=new File("E://TestData17thJan.txt");
		
		
		RestAssured.baseURI="https://httpbin.org";
		
		 Response res=		given().log().all().
				
				headers("content-type","multipart/form-data")
				.multiPart("File",f).
				
				
				
				
				when().post("post").
			    then().log().all().assertThat().statusCode(200)
			    .extract().response();
		 
		 System.out.println(res.asString());
		 
		
		 
		 
		 
		 

	}

}
