package Authentications;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;

public class BearerTokenEx {

	public static void main(String[] args) {
		
		
		String token ="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		
		Map<String,Object> payload=new LinkedHashMap<String,Object>();
		payload.put("name", "Harry");
		payload.put("gender", "male");
		payload.put("email", "grftyh@gmail.com");
		payload.put("status", "active");
		
		RestAssured.baseURI="https://gorest.co.in";
		
	String Response=	given().log().all().headers("content-type","application/json")
		.header("Authorization",token).body(payload)
		
		.when().post("public/v2/users")
		
		
		.then().assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println(Response);
		
		
		
		
		
		
		
		

	}

}
