package Authentications;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class DigestAuthenticationEx {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://httpbin.org/digest-auth";
		
	String Response=	given().log().all().auth().
			digest("saurabh", "saurabh")
			
			
			
		.when().get("undefined/saurabh/saurabh")
		.then().log().all().
		extract().response().asString();
	
	System.out.println(Response);
		
		
		
		

	}

}
