package Authentications;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class BasicAuthentication {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://postman-echo.com";
		
	String Response=	given().log().all().auth().preemptive().
			basic("postman","password")
			
			
		.when().get("basic-auth")
		.then().log().all().
		assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
		

	}

}
