package MyPractice1;

import static io.restassured.RestAssured.given;

import java.util.UUID;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class IdempotentKey {

	public static void main(String[] args) {
		
		String idempotencyKey = UUID.randomUUID().toString();
		
		
		
		
		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				headers("Idempotency-Key",idempotencyKey).
				body(Payload.addEmployeeDetails("harry","QA manager")).
				
				
				
				when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response();
		 
		 System.out.println(res.asString());
		
		

	}

}
