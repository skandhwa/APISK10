package MyPractice1;

import org.testng.Assert;

import ResponseJSON.ResponsePayload;
import io.restassured.path.json.JsonPath;

public class DahboardTestCases {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(ResponsePayload.DashboardResponse());		
		///Print No of courses returned by API

		int course_size=js.getInt("courses.size()");
		System.out.println("Total number of courses are  "+course_size);
		
		
		///Print Purchase Amount

		int amount =js.getInt("dashboard.purchaseAmount");
		System.out.println("Purchase amount is  "+amount);
		
		// Print Title of the first course

		String title=js.getString("courses[0].title");
		System.out.println("Title of first course is  "+title);
		
		//Print All course titles and their respective Prices

		System.out.println("Title of all courses and their price is ");
		for(int i=0;i<course_size;i++)
		{
			String titleAllCourse= js.getString("courses["+i+"].title");
			int priceAllCourse= js.getInt("courses["+i+"].price");
			
			System.out.println(titleAllCourse+"  "+priceAllCourse);
			
		}
		
		for(int i=0;i<course_size;i++)
		{
			if(js.getString("courses["+i+"].title").equals("RPA"))
			{
				int copies=js.getInt("courses["+i+"].copies");
				System.out.println("Total copies sold by RPA is  "+copies);
			}
		}
		
		int Rpa_CourseSize=js.getInt("courses[2].copies");
		System.out.println("Totsl copies sold by RPA is  "+Rpa_CourseSize);
		
		
		int sum=0;
		for(int i=0;i<course_size;i++)
		{
			
			int price=	js.getInt("courses["+i+"].price");
			int copies= js.getInt("courses["+i+"].copies");
			int totalamount =price*copies;
			sum=sum+totalamount;
			
			
		}
		
		System.out.println("The total dashboard amount  is  "+sum);
		
		Assert.assertEquals(sum, amount);
		
		System.out.println("All Test case passed");
		
		

	}

}
