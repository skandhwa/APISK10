package MyPractice1;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadData.Payload;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class TestNgDpToPassMultipleData {

	@DataProvider(name="booksData")
	public Object [][] getData()
	{
		return new Object [][]
	{
			{"Appium Skills","erfy","4567"},
			{"PlaywrightTutorial","kjhg","8765"},
			{"Python Skill","nbfd","9432"}
				
	};
				
				
	}
	
	@Test(dataProvider="booksData")
	public void addBook(String bookname,String isbn,String aisle )
	{
    String Response=		RestAssured.baseURI="http://216.10.245.166";
		given().log().all().headers("Content-type","application/json")
		.body(Payload.addBook1(bookname, isbn, aisle))
		.when().post("Library/Addbook.php")
		.then().assertThat().statusCode(200)
		.extract().response().asString();
		
		System.out.println(Response);
		
		
		
		
	}
	
	

	
	

}
