package MyBasics;

public class LogicalOperators {

	public static void main(String[] args) {
	
		int a=100,b=50,c=20;
		
		if(a>b && b>c) ///100>15 && 150>20
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("Hi");
		}
		

	}

}
