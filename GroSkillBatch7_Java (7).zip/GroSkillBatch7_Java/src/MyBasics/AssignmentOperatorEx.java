package MyBasics;

public class AssignmentOperatorEx {

	public static void main(String[] args) {
		
		int a=10;
		
		a-=4; // a=a+4=10+4=14
		
		System.out.println(a);
		

	}

}
