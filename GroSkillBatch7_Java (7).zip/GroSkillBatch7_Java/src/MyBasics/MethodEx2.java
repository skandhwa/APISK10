package MyBasics;

class A2
{
	void test(int x)
	{
		int y=x+10;
		System.out.println(y);
	}
	
	void sum(int x,int y,int z)
	{
		int r=x+y+z;
		System.out.println(r);
	}
}


public class MethodEx2 {

	public static void main(String[] args) {
		
		A2 obj=new A2();
		
		obj.test(23);
		
		obj.sum(34,56,78);
		
		
		
		
		

	}

}
