package MyBasics;

public class LogicalNotEx {

	public static void main(String[] args) {
		
		int a=15,b=10;
		
		System.out.println(a!=b);
		

	}

}
