package MyBasics;

public class LogicalOREx {

	public static void main(String[] args) {
		
        int a=100,b=5,c=20;
		
		if(a>b || b>c) ///100>15 && 5>20
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("Hi");
		}
		
		

	}

}
