package MyBasics;

class A
{
	int x=10;
	
	void test()
	{
		int y=x+10;
		System.out.println(y);
	}
	void display()
	{
		int z=y+30;
		System.out.println(z);
	}
	
	
}


public class VariableEx {

	public static void main(String[] args) {
		
		
		

	}

}
