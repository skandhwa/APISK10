package MyBasics;

public class TernaryOpearatorEx {

	public static void main(String[] args) {
		
//		int a=10,b=8;
//		
//		int max= a>b ?a:b;
//		
//		System.out.println(max);
		
		
		int a=15,b=10,c=20;
		
		int max= a>b ?(a>c?a:c) :(b>c?b:c);
		
		
		
		

	}

}
