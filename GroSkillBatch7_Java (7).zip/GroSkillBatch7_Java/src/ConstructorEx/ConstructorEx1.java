package ConstructorEx;

class P1
{
	 P1()
	{
		System.out.println("hi");
	}
	
	void test()
	{
		System.out.println("hello");
	}
}



public class ConstructorEx1 {

	public static void main(String[] args) {
		
		P1 obj=new P1();
		obj.test();
		
		
		
		

	}

}
