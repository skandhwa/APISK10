package ConstructorEx;

class A3
{
	int id;
	String name;
	
	A3(int i,String n)
	{
		id=i;
		name=n;
		System.out.println(id+"  "+name  );
	}
	
//	void display()
//	{
//		System.out.println(id+"  "+name);
//	}
	
	
}
public class ParameterizedConstructorEx {

	public static void main(String[] args) {
		
		A3 obj=new A3(12,"Harry");
		//obj.display();
		
		
		
		
		
		
		

	}

}
