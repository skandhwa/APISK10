package InheritanceEx1;

class A10
{
	void display()
	{
		System.out.println("Hello");
	}
}

class B10 extends A10
{
	void display()
	{
		System.out.println("Hi");
	}
	void test()
	{
		System.out.println("Java");
	}
	
	void msg()
	{
		System.out.println("Python");
	}
	
	void run()
	{
		display();
		test();
		msg();
		super.display();
	}
	
}



public class SuperMethodEx {

	public static void main(String[] args) {
		
		B10 obj=new B10();
		obj.run();
		
		
		

	}

}
