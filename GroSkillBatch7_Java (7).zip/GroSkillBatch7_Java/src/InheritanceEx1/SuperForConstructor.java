package InheritanceEx1;


class Animal1
{
	Animal1()
	{
		System.out.println("Animal Created");
	}
}

class Dog1 extends Animal1
{
	Dog1()
	{
		super();
		System.out.println("Dog created");
		
	}
	
	
}





public class SuperForConstructor {

	public static void main(String[] args) {
		
		Dog1 obj=new Dog1();
		
		

	}

}
