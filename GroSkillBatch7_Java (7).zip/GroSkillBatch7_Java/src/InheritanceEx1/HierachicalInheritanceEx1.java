package InheritanceEx1;

class A3
{
	void test()
	{
		System.out.println("hello");
	}
}

class B3 extends A3 
{
	void display()
	{
		System.out.println("Hi");
	}
}


class C3 extends A3
{
	void msg()
	{
		System.out.println("Java");
	}
}



public class HierachicalInheritanceEx1 {

	public static void main(String[] args) {
		
		C3 obj=new C3();
		obj.msg();
		obj.test();
		
		B3 obj1=new B3();
		obj1.test();
		obj1.display();
		
		
		
		
		

	}

}
