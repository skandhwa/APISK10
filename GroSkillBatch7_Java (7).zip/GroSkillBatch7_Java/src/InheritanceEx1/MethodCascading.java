package InheritanceEx1;


class B4
{
	void display()
	{
		System.out.println("Hi");
	}
	
	void test()
	{
		System.out.println("Hello");
	}
	
	void msg()
	{
		System.out.println("Java");
	}
	
	void run()
	{
		display();
		test();
		msg();
	}
	
	
	
}







public class MethodCascading {

	public static void main(String[] args) {
		
		B4 obj=new B4();
//		obj.msg();
//		obj.test();
//		obj.display();
		
		obj.run();
		

	}

}
