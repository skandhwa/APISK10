package InheritanceEx1;

class A
{
	int x=10;
	void test()
	{
		System.out.println("hello");
		
	}
}

class B extends A
{
	int x=20;
	void display()
	{
		System.out.println("This is Java");
		
	}
}




public class SingleLevelInheritance {

	public static void main(String[] args) {
		
		B obj=new B();
		obj.test();
		
	System.out.println(obj.x);	
		

	}

}
