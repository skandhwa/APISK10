package StaticKeyword;

 class D6
{
	static class D7
	{
		static void display()
		{
			System.out.println("static inner class");
		}
	}
}



public class StaticClass {

	public static void main(String[] args) {
		
//		D6.D7 obj=new D6.D7();
//		
//		obj.display();
		
		
		D6.D7.display();
		

	}

}
