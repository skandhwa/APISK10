package StaticKeyword;

class D4
{
	 void test()
	{
		System.out.println("hello");
	}
}

class D5 extends D4
{
	void show()
	{
		System.out.println("Hi");
	}
	void test()
	{
		System.out.println("Java");
	}
	
	void run()
	{
		show();
		test();
		super.test();
	}
}


public class SuperWithStaticMethod {

	public static void main(String[] args) {
		
		D5 obj=new D5();
		obj.run();
		
		
		

	}

}
