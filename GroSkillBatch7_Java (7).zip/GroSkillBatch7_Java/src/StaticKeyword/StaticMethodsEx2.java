package StaticKeyword;

class C4
{
	static int sum(int x,int y)
	{
		return x+y;
	}
}


public class StaticMethodsEx2 {

	public static void main(String[] args) {
		
	System.out.println(C4.sum(20,30));	
		

	}

}
