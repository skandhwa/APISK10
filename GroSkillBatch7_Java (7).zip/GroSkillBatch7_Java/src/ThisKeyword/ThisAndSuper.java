package ThisKeyword;

class Bird
{
	int x=20;
	
}

class Crow extends Bird
{
	int x=40;
	void run()
	{
		
		System.out.println(this.x);
		System.out.println(x);
		System.out.println(super.x);
	}
	
}



public class ThisAndSuper {

	public static void main(String[] args) {
		

	}

}
