package PolymorphismEx;

class D16
{
	void display(int x,int z)
	{
		System.out.println("First display");
	}
	
	int display(int y,float h)
	{
		System.out.println("second display");
		return 5;
	}
}


public class MethodOverloadingEx1 {

	public static void main(String[] args) {
		
		D16 obj=new D16();
		obj.display(12, 34);
		
		obj.display(34, 56.6f);
		
		
		

	}

}
