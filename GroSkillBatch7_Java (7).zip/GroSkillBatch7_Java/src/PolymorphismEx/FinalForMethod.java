package PolymorphismEx;

class B50
{
	final static int mul(int x,int y)
	{
		return x*y;
	}
}


class B51 extends B50
{
	int mul(int x,int y)
	{
		return x*y;
	}
}

class B52 extends B50
{
	int mul(int x,int y)
	{
		return x*y;
	}
}



public class FinalForMethod {

	public static void main(String[] args) {
		

	}

}
