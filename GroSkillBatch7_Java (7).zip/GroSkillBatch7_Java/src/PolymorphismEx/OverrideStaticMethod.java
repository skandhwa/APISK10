package PolymorphismEx;

class D20
{
	static int sum(int a,int b)
	{
		return a+b;
	}
}

class D23 extends D20
{
	int sum(int a,int b)
	{
		return a+b;
	}
}

class D22 extends D20
{
	int sum(int a,int b)
	{
		return a+b;
	}
}

public class OverrideStaticMethod {

	public static void main(String[] args) {
		

	}

}
