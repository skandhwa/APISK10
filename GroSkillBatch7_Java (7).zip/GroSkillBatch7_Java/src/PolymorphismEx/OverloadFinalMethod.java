package PolymorphismEx;


class E10
{
	final int sum(int x,int y)
	{
		return x+y;
	}
	
	final int sum(int x,int y,int z)
	{
		return x+y+z;
	}
}

public class OverloadFinalMethod {

	public static void main(String[] args) {
		

	}

}
