package PolymorphismEx;


final class B70
{
	void test()
	{
		System.out.println("Hello");
	}
}


class B71 extends B70
{
	void msg()
	{
		System.out.println("Hi");
	}
}


public class FinalforClass {

	public static void main(String[] args) {
		

	}

}
