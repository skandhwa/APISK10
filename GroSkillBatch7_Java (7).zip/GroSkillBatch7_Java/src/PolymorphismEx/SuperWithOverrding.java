package PolymorphismEx;

class D30
{
	void test()
	{
		System.out.println("Hello");
	}
}

class D31 extends D30
{
	void test()
	{
		System.out.println("Hi");
	}
	void run()
	{
		test();
		super.test();
	}
	
}



public class SuperWithOverrding {

	public static void main(String[] args) {
		

	}

}
