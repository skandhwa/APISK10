package PolymorphismEx;


class D21
{
	private int add(int x,int y)
	{ 
		return x+y;
	}
	
	int add(int x,int y,int z)
	{
		return x+y+z;
	}
	
	private float add(float x,int y)
	{
		return x+y;
	}
	
	int add()
	{
		return 5;
	}
}

public class MethodOverloadingEx2 {

	public static void main(String[] args) {
		
		D21 obj=new D21();
	System.out.println(obj.add(20,34,56));	
	
	  System.out.println(obj.add(56,67));  
	  
	  System.out.println (obj.add(56f,78));
	  
	 
	  
	  
		
		
		
		
		

	}

}
