package PolymorphismEx;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	} 
}

class Axis extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	} 
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	} 
}




public class MethodOverridingEx1 {

	public static void main(String[] args) {
		
		Bank obj=new Bank();
	System.out.println(obj.getROI(3, 6)); 
	
	HDFC obj1=new HDFC();
	System.out.println(obj1.getROI(7, 5)); 
		

	}

}
