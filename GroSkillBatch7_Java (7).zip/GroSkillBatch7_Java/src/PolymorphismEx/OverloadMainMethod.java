package PolymorphismEx;

public class OverloadMainMethod 
{
	
	public static void main(String str)
	{
		int x= str.length();
		System.out.println(x);
	}
	
	
	
	

	public static void main(String[] args) 
	{
		System.out.println("Hello");
	OverloadMainMethod.main("Saurabh");	
		

	}

}
