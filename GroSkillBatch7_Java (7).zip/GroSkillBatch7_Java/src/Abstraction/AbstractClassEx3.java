package Abstraction;

 abstract class Animal
{
	final int x=29;
	Animal()
	{
		System.out.println("This is an Animal");
	}
}

class Dog extends Animal
{
	
	Dog()
	{
		super();
		System.out.println("This is an Dog");
		
	}
}


public class AbstractClassEx3 {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		
		

	}

}
