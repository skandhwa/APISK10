package Abstraction;

abstract class B1
{
	int id;
	String name;
	
	B1(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	void display()
	{
		System.out.println(id+"  "+name);
	}
	
}


public class AbstractClassEx2 {

	public static void main(String[] args) {
		
		B1 obj=new B1(1234,"Harry");
		obj.display();
		

	}

}
