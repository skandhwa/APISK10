package APISK10UsingXMLAsPayload;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class SendingXMLAsRequest {

	public static void main(String[] args) {
		
	
		
		RestAssured.baseURI="https://petstore.swagger.io";
		
	String Response=	given().log().all().body(XMLPayload.xmlPayload())
		.header("content-type","application/xml")
		.when().post("v2/pet")
		.then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	js.get("");
		

	}

}
