package APISK10Serialization5;

import java.util.List;

public class EmployeePOJO5 {
	
	private String name;
	private int age;
	private double salary;
	private List<String> banks;
	private EmployeeAddressPOJO empObj;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	public EmployeeAddressPOJO getEmpObj() {
		return empObj;
	}
	public void setEmpObj(EmployeeAddressPOJO empObj) {
		this.empObj = empObj;
	}
	
	
	

}
