package APISK10Serialization5;

import java.util.List;

public class HouseDetailsPOJO {
	
	private  FlatDetailsPOJO fltObj;
	private String street;
	private List<String> landmark;
	
	
	public FlatDetailsPOJO getFltObj() {
		return fltObj;
	}
	public void setFltObj(FlatDetailsPOJO fltObj) {
		this.fltObj = fltObj;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public List<String> getLandmark() {
		return landmark;
	}
	public void setLandmark(List<String> landmark) {
		this.landmark = landmark;
	}
	
	
	
	
	

}
