package APISK10_ExcelIntegrationRestAssured;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class MyTest1 {

	public static void main(String[] args) throws Exception {
		
		
		ExcelIntegrationEx obj=new ExcelIntegrationEx(ConstantsData.EXCEL_PATH,ConstantsData.SHEET_NAME);
		Map<Object,Object> mp=new LinkedHashMap<Object,Object>();
		mp.put("name",ExcelIntegrationEx.getData(1,0));
		mp.put("id",ExcelIntegrationEx.getData(1, 1) );
		mp.put("salary",ExcelIntegrationEx.getData(1, 2) );
		mp.put("gender",ExcelIntegrationEx.getData(1, 3) );
		
		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				body(Payload.addEmployeeDetails("harry","QA manager")).
				
				
				
				when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response();
		 
		long time= res.getTime();
		
		System.out.println(time);
		
		if(time>5000)
		{
			throw new Exception("Time limit exceeded");
		}
		else
		{
			System.out.println("Test case passed");
		}
		 
		 

	}

		

	}


