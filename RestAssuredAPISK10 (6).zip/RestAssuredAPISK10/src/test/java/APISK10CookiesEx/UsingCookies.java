package APISK10CookiesEx;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;

import APISK10_Payload.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UsingCookies {

	public static void main(String[] args) throws HttpTimeoutException {
		
		RestAssured.baseURI="https://reqres.in";
		
		Response res=	given().log().all().cookies(CreateCookie.cookieData()).
			headers("content-type","application/json").
			headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
			.body(Payload.payloadData("Harry","Director"))
			
			
			.when().post("api/users")
			.then().assertThat().statusCode(201)
			.extract().response();
		
		long time=res.getTime();
		
		if(time>5000)
		{
			throw new HttpTimeoutException("Time limit exceeded");
		}
		
		else{
			
			System.out.println("Test case passed");
			
		}
		
		
		
		System.out.println(res.asString());
		
		

	}

}
