package APISK10CookiesEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class CreateCookie {
	
	public static Map cookieData()
	{
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("username","harry");
		mp.put("password", "test@1234");
		
		return mp;
		
		
		
	}
	

}
