package APISK10SessionFilter;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class SessionFilterEx {

	SessionFilter s;
	
	@BeforeTest
	public SessionFilter captureSessionId()
	{
		s=new SessionFilter();
		return s;
	}
	
	@Test
	public void myTest1() throws Exception
	{
RestAssured.baseURI="https://reqres.in";
		
		String Expectedfirst_name="Tobias";
		
		
		
		 Response res=		given().log().all().filter(s).
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				queryParam("page",2).
				headers("content-type","application/json").
				when().get("api/users").
			    then().log().all().assertThat().statusCode(200)
			    .extract().response();
		 
		 
		 String Response=res.asString();
			
			JsonPath js=new JsonPath(Response);
			
		String featureVal=	js.getString("_meta.features[2]");
		
		System.out.println(featureVal);
		
		 String Actual_firstname=js.getString("data[2].first_name");
		 
		 Assert.assertEquals(Actual_firstname, Expectedfirst_name);
		 
		long time= res.getTime();
		
		System.out.println(time);
		
		if(time>5000)
		{
			throw new Exception("Time limit exceeded");
		}
		else
		{
			System.out.println("Test case passed");
		}
		 
		
	}
	
	
	public void test2()
	{
		RestAssured.baseURI="https://reqres.in";
		
		 String Response=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").filter(s).
				when().get("api/users/2").
			    then().log().all().extract().response().asString();
		 
		 System.out.println(Response);
		 
		JsonPath js=new JsonPath(Response);
		 
		 String LastName=js.get("data.last_name");
		 Assert.assertEquals("Weaver", LastName);
		 
		 
		 
		 
	}
	

}
