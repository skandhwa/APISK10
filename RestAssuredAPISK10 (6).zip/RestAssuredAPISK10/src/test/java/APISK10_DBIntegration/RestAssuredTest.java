package APISK10_DBIntegration;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class RestAssuredTest {

	public static void main(String[] args) throws Exception {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("id",CreateConnectionDB.createConnection(1));
		mp.put("name",CreateConnectionDB.createConnection(2));
		mp.put("address",CreateConnectionDB.createConnection(3));
		mp.put("age",CreateConnectionDB.createConnection(4));
		mp.put("salary",CreateConnectionDB.createConnection(5));
		mp.put("status",CreateConnectionDB.createConnection(6));
		

		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				body(mp).
				
				
				
				when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response();
		 
		long time= res.getTime();
		
		System.out.println(time);
		
		if(time>5000)
		{
			throw new Exception("Time limit exceeded");
		}
		else
		{
			System.out.println("Test case passed");
		}
		 
		 

	}
		

	}


