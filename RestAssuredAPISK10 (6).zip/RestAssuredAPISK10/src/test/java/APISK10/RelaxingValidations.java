package APISK10;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class RelaxingValidations {

	public static void main(String[] args) {
		
	String Response=	given().log().all().relaxedHTTPSValidation()
		
		.when().get("https://self-signed.badssl.com/")
		.then().log().all().extract().response().asString();
	
	System.out.println(Response);
		

	}

}
