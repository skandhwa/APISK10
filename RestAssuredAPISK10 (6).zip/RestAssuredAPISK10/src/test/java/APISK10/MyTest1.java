package APISK10;

import io.restassured.RestAssured.*;
import static io.restassured.RestAssured.*;

public class MyTest1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all()
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.headers("Content-Type","application/json")
		
		
		.when().get("api/users")
		
		.then().log().all().
		extract().response().asString();
	
	System.out.println(Response);
		
		
		
		
		
		
		

	}

}
