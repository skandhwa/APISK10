package APISK10RequestResponseSpecification;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReqResCommon {
	
	public static RequestSpecification getReq()
	{
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON).
				addHeader("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
				.build();
		
		return req;
	}
	
	public static ResponseSpecification getRes(int code)
	{
	ResponseSpecification respec=new ResponseSpecBuilder().
			expectStatusCode(code).expectContentType(ContentType.JSON)
			.build();
	
	return respec;
	

}
}
