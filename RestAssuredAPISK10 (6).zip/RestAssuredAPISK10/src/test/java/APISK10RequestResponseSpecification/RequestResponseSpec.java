package APISK10RequestResponseSpecification;

import static io.restassured.RestAssured.given;

import PayloadData.Payload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class RequestResponseSpec {

	public static void main(String[] args) {
		
		
		
RequestSpecification res=given().log().all().spec(ReqResCommon.getReq()).
				body(Payload.addEmployeeDetails("harry", "QA lead"));
		
		
		
String Response=	res.when().post("api/users").then().log().all().
		spec(ReqResCommon.getRes(201)).extract().response().asString();
	
	System.out.println(Response);
		
		
		
		
		
		

	}

}
