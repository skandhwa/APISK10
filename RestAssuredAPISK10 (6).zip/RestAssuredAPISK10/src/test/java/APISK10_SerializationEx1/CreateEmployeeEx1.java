package APISK10_SerializationEx1;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import APISK10_Payload.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployeeEx1 {

	public static void main(String[] args) throws JsonProcessingException, HttpTimeoutException {
		
		EmployeePOJOEx1 emp=new EmployeePOJOEx1();
		emp.setName("Harry");
		emp.setAddress("NCR");
		emp.setSalary(90000);
		emp.setId(1234);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJson=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		
		RestAssured.baseURI="https://reqres.in";
		
		Response res=	given().log().all()
			.headers("content-type","application/json").
			headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
			.body(empJson)
			
			
			.when().post("api/users")
			.then().assertThat().statusCode(201)
			.extract().response();
		
		long time=res.getTime();
		
		if(time>5000)
		{
			throw new HttpTimeoutException("Time limit exceeded");
		}
		
		else{
			
			System.out.println("Test case passed");
			
		}
		
		
		
		System.out.println(res.asString());
		
		
		
		
		

	}

}
