Feature: Validate Add to Cart

  Background: 
    Given user opens the browser url of facebook
    And user enters the username as "test"
    And user enters the password as "test1234"
    When user clicks on login button of facebook
    Then user lands into the HomePage of the application

@smoke
  Scenario: Test Add to Cart functionality
    Then user searches reebok shoe and add that to cart

  Scenario: Test Add to Cart functionality multiple products
    Then user searches titan watch and add that to cart
    Then user searches apple iphone and add that to cart
    Then user searches puma tshirt and add that to cart

  Scenario: Test Add to Cart functionality multiple products add and delete
    Then user searches titan watch and add that to cart
    Then user searches apple iphone and add that to cart
    Then user searches puma tshirt and add that to cart
    Then user removes one product and now count of product is 2
    Then user removes one more product and now count of product is 1
